//
//  ProfileVC+Avatar.swift
//  ReadAndRoad
//
//  Created by Weiqing Gao on 12/10/25.
//

import UIKit

extension ProfileViewController {

    /// Placeholder for future avatar selection logic.
    func setupAvatarHandler() {
        // Future: UIImagePickerController for avatar upload
    }
}
