//
//  APIConfig.swift
//  ReadAndRoad
//
//  Created by Weiqing Gao on 11/10/25.
//

import Foundation

struct APIConfigs {
    static let baseURL = "https://example.com/api/"   // dummy url
}
