//
//  SavedPostsView.swift
//  ReadAndRoad
//
//  Created by Weiqing Gao on 11/10/25.
//

import UIKit

class SavedPostsView: UIView {

}
